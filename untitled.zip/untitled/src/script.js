//Array (Arreglo) para las imagenes, aqui van a poner las imagenes//
// de cada uno//

const imagenes = ["https://plus.unsplash.com/premium_photo-1756757313440-eee42d853d80?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHwxN3x8fGVufDB8fHx8fA%3D%3D",
                  
"https://plus.unsplash.com/premium_photo-1757100707952-6ca4d55afce4?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw0NXx8fGVufDB8fHx8fA%3D%3D",
                  
"https://plus.unsplash.com/premium_photo-1756921174793-46a2a13d8f9e?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw4MXx8fGVufDB8fHx8fA%3D%3D",
                  
"https://images.unsplash.com/photo-1756850585212-365a3596e74a?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw5Mnx8fGVufDB8fHx8fA%3D%3D",
                  
"https://plus.unsplash.com/premium_photo-1677486562527-45d0f7d756e6?q=80&w=426&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"                
];

//seleccion de elementos//

const boton = document.getElementById("btn-cambiar");

const imagenCard = document.getElementById("card-img");

const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

// Evento del click //

boton.addEventListener("click", ()=>
{
  //lo siguiente es para que avance la foto //
  indice++;
  
  //el siguiente if es para cuando llegue al final se regreso al inicio//
  
  if(indice >= imagenes.length){
    indice = 0;
  }

  // Cambiar imagen y texto
  imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`
});